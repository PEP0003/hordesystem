execute positioned 64 ~ ~ run summon minecraft:zombie ~ ~ ~ {Tags:["horde_mob"]}
execute positioned 349 ~ ~ run summon minecraft:zombie ~ ~ ~ {Tags:["horde_mob"]}

execute positioned ~ ~ 175 run summon minecraft:zombie ~ ~ ~ {Tags:["horde_mob"]}
execute positioned ~ ~ 326 run summon minecraft:zombie ~ ~ ~ {Tags:["horde_mob"]}

execute positioned 64 ~ ~ run summon minecraft:zombie ~5 ~ ~ {Tags:["horde_mob"]}