execute as @a[limit=1] if predicate horde:random_33 run scoreboard players set #roll horde_roll 2
execute as @a[limit=1] unless predicate horde:random_33 run function horde:roll_3_4