execute as @a[limit=1] if predicate horde:random_50 run scoreboard players set #roll horde_roll 3
execute as @a[limit=1] unless predicate horde:random_50 run scoreboard players set #roll horde_roll 4