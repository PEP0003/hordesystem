summon minecraft:zombie ~32 ~ ~ {Tags:["horde_mob"]}
summon minecraft:zombie ~-32 ~ ~ {Tags:["horde_mob"]}
summon minecraft:zombie ~ ~ ~32 {Tags:["horde_mob"]}
summon minecraft:zombie ~ ~ ~-32 {Tags:["horde_mob"]}
summon minecraft:zombie ~23 ~ ~23 {Tags:["horde_mob"]}